sudo apt-get update
sudo apt-get install python3 python3-dev python3-numpy python3-pip python3-opencv portaudio19-dev git ffmpeg python3-flask
pip3 install --upgrade pip
pip3 install pillow pydub soundfile numpy opencv-python opencv-contrib-python uuid amodem ffmpeg-python cryptography flask
python3 flaskapp.py
